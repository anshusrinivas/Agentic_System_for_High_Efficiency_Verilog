mkdir power
mkdir area
mkdir gate_count

genus -f script_file.tcl
sleep 10
cp *_power.rep ./power
cp *_area.rep ./area
cp *_GateCount.rep ./gate_count

echo "Operation successful"
