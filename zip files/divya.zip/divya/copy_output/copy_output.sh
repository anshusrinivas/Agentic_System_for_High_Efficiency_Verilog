#!/bin/bash

# Source file (simulation output path)
SRC="/home/user02/divya/output/output.txt"

# Destination directory in YOUR home
DEST="/home/user02/final_results/doc"

# Create destination directory if it doesn't exist
mkdir -p "$DEST"

# Copy the file
cp "$SRC" "$DEST/"

echo "Output file copied to $DEST/"

